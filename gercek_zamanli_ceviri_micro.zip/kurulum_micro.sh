#!/bin/bash

# Mikro Model ile Hızlı ve Offline Altyazı + Çeviri + Seslendirme Kurulumu (API'siz, dosyasız)

set -e

# Sistem gereksinimleri kuruluyor
sudo apt update && sudo apt install -y ffmpeg git python3-pip wget unzip

# Python kütüphaneleri
pip3 install --upgrade pip
pip3 install torch torchvision torchaudio --index-url https://download.pytorch.org/whl/cpu
pip3 install faster-whisper
pip3 install argostranslate
pip3 install TTS
pip3 install websockets aiohttp numpy soundfile

# Argos çeviri modeli (İngilizce → Türkçe)
mkdir -p models && cd models
wget -nc https://www.argosopentech.com/argospm/translate-en_tr.argosmodel
python3 -c "import argostranslate.package; argostranslate.package.install_from_path('translate-en_tr.argosmodel')"
cd ..

# backend_micro.py oluşturuluyor
cat > backend_micro.py << 'EOF'
import asyncio, websockets, subprocess, base64, io, sys, json
from faster_whisper import WhisperModel
import argostranslate.translate
from TTS.api import TTS
import soundfile as sf
import numpy as np

if len(sys.argv) != 2:
    print("Kullanım: python3 backend_micro.py \"https://yayınadresiniz.m3u8\"")
    sys.exit(1)

M3U8_URL = sys.argv[1]

installed_languages = argostranslate.translate.get_installed_languages()
from_lang = [l for l in installed_languages if l.code == "en"][0]
to_lang = [l for l in installed_languages if l.code == "tr"][0]
translation_fn = from_lang.get_translation(to_lang)

whisper_model = WhisperModel("tiny", compute_type="int8")
tts = TTS(model_name="tts_models/tr/css10/vits", gpu=False)

def stream_audio():
    cmd = ["ffmpeg", "-i", M3U8_URL, "-f", "s16le", "-acodec", "pcm_s16le", "-ar", "16000", "-ac", "1", "-loglevel", "quiet", "-"]
    return subprocess.Popen(cmd, stdout=subprocess.PIPE, bufsize=4096)

def json_response(original, translated, audio_b64):
    return json.dumps({"original": original, "translated": translated, "audio": audio_b64})

async def handler(websocket):
    print("WebSocket bağlantısı kuruldu.")
    proc = stream_audio()
    while True:
        audio_data = proc.stdout.read(16000 * 2 * 5)
        if not audio_data:
            continue
        audio_np = np.frombuffer(audio_data, dtype=np.int16).astype(np.float32) / 32768.0
        segments, _ = whisper_model.transcribe(audio_np, beam_size=5)
        original = " ".join([seg.text for seg in segments])
        translated = translation_fn.translate(original)
        wav, sr = tts.tts(text=translated, raw=True)
        buf = io.BytesIO()
        sf.write(buf, wav, sr, format="WAV")
        encoded_audio = base64.b64encode(buf.getvalue()).decode("utf-8")
        await websocket.send(json_response(original, translated, encoded_audio))

async def main():
    async with websockets.serve(handler, "localhost", 8765):
        print("WebSocket sunucusu çalışıyor: ws://localhost:8765")
        await asyncio.Future()

if __name__ == "__main__":
    asyncio.run(main())
EOF

# Tarayıcı arayüzü
cat > index.html << 'EOF'
<!DOCTYPE html>
<html>
<head><meta charset="utf-8"><title>Gerçek Zamanlı Çeviri</title></head>
<body>
<h2>Çeviri:</h2>
<div id="sub" style="font-size:24px;color:#333;"></div>
<script>
let ws = new WebSocket("ws://localhost:8765");
ws.onmessage = (event) => {
    const data = JSON.parse(event.data);
    document.getElementById("sub").innerText = data.translated;
    const audio = new Audio("data:audio/wav;base64," + data.audio);
    audio.play();
};
</script>
</body>
</html>
EOF

chmod +x backend_micro.py

echo "Kurulum tamamlandı."
echo "Çalıştırmak için:"
echo "python3 backend_micro.py \"https://orneklink.m3u8\""
echo "index.html dosyasını tarayıcıda açın."
